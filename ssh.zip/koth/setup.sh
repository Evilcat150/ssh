#!/bin/bash
# Setup script for KotH exploitation tools
# Run this on Kali Linux before executing any exploits
#
# Usage: chmod +x setup.sh && ./setup.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$SCRIPT_DIR/venv"

echo "[*] === KotH Environment Setup ==="
echo "[*] Script directory: $SCRIPT_DIR"

# --- Create virtual environment ---
if [ -d "$VENV_DIR" ]; then
    echo "[*] Virtual environment already exists at $VENV_DIR"
else
    echo "[*] Creating Python virtual environment..."
    python3 -m venv "$VENV_DIR"
    echo "[+] Virtual environment created"
fi

# --- Activate and install dependencies ---
sudo apt install ysoserial

echo "[*] Installing dependencies..."
source "$VENV_DIR/bin/activate"

pip install --upgrade pip > /dev/null 2>&1
pip install requests urllib3 > /dev/null 2>&1
pip install base64 > /dev/null 2>&1
pip install io > /dev/null 2>&1
pip install json > /dev/null 2>&1
pip install os > /dev/null 2>&1
pip install random > /dev/null 2>&1
pip install requests > /dev/null 2>&1
pip install string > /dev/null 2>&1
pip install struct > /dev/null 2>&1
pip install subprocess > /dev/null 2>&1
pip install sys > /dev/null 2>&1
pip install tempfile > /dev/null 2>&1
pip install time > /dev/null 2>&1
pip install urllib3 > /dev/null 2>&1
pip install zipfile > /dev/null 2>&1

echo "[+] Installed: requests, urllib3, base64, io, json, os, random, string, struct, subprocess, sys, tempfile, time, urllib3, zipfile"

# --- Verify ---
echo "[*] Verifying installation..."
python3 -c "import requests; print(f'[+] requests {requests.__version__}')"
python3 -c "import urllib3; print(f'[+] urllib3 {urllib3.__version__}')"
python3 -c "import base64; print(f'[+] base64 {base64.__version__}')"
python3 -c "import io; print(f'[+] io {io.__version__}')"
python3 -c "import json; print(f'[+] json {json.__version__}')"
python3 -c "import os; print(f'[+] os {os.__version__}')"
python3 -c "import random; print(f'[+] random {random.__version__}')"
python3 -c "import string; print(f'[+] string {string.__version__}')"
python3 -c "import struct; print(f'[+] struct {struct.__version__}')"
python3 -c "import subprocess; print(f'[+] subprocess {subprocess.__version__}')"
python3 -c "import sys; print(f'[+] sys {sys.__version__}')"
python3 -c "import tempfile; print(f'[+] tempfile {tempfile.__version__}')"
python3 -c "import time; print(f'[+] time {time.__version__}')"
python3 -c "import urllib3; print(f'[+] urllib3 {urllib3.__version__}')"
python3 -c "import zipfile; print(f'[+] zipfile {zipfile.__version__}')"

# --- Make scripts executable ---
chmod +x "$SCRIPT_DIR"/*.py 2>/dev/null || true
chmod +x "$SCRIPT_DIR"/*.sh 2>/dev/null || true

echo ""
echo "[+] === Setup Complete ==="
echo "[*] To activate the environment:"
echo "    source $VENV_DIR/bin/activate"
echo ""
echo "[*] To run all exploits:"
echo "    source venv/bin/activate && python3 run_all.py"
echo ""
echo "[*] To run a single exploit:"
echo "    source venv/bin/activate && python3 run_all.py --target 172.29.3.26"

source venv/bin/activate
python3 run_all.py
