#!/usr/bin/env python3
"""
Master orchestrator for KotH exploitation scripts.
Runs all exploits sequentially and provides a summary.

Usage: python run_all.py [--target TARGET_IP]
       python run_all.py                   # runs all targets
       python run_all.py --target 172.29.3.26   # only Jenkins
"""

import subprocess
import sys
import os
import time
import argparse

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

TARGETS = {
    "172.29.3.26": {
        "name": "Jenkins 2.440",
        "cve": "CVE-2024-23897",
        "script": "exploit_jenkins.py",
    },
    "172.29.3.121": {
        "name": "Apache Druid 0.20.0",
        "cve": "CVE-2021-25646",
        "script": "exploit_druid.py",
    },
    "172.29.3.124": {
        "name": "Apache Tomcat 8.5.19",
        "cve": "CVE-2017-12615",
        "script": "exploit_tomcat_85.py",
    },
    "172.29.3.181": {
        "name": "Apache Tomcat 9.0.89",
        "cve": "CVE-2025-24813",
        "script": "exploit_tomcat_90.py",
    },
}


def run_exploit(ip, info):
    """Run a single exploit script and return result."""
    script_path = os.path.join(SCRIPT_DIR, info["script"])
    
    if not os.path.exists(script_path):
        print(f"  [-] Script not found: {script_path}")
        return False, "Script not found"
    
    print(f"\n{'='*70}")
    print(f"  TARGET: {ip} — {info['name']}")
    print(f"  CVE:    {info['cve']}")
    print(f"  Script: {info['script']}")
    print(f"{'='*70}\n")
    
    try:
        result = subprocess.run(
            [sys.executable, script_path],
            cwd=SCRIPT_DIR,
            timeout=300,  # 5 minute timeout per target
            capture_output=False,  # Let output go to terminal
        )
        
        if result.returncode == 0:
            return True, "Success"
        else:
            return False, f"Exit code: {result.returncode}"
            
    except subprocess.TimeoutExpired:
        return False, "Timed out (5 min)"
    except Exception as e:
        return False, str(e)


def main():
    parser = argparse.ArgumentParser(description="KotH Master Exploit Orchestrator")
    parser.add_argument("--target", "-t", help="Specific target IP to exploit")
    args = parser.parse_args()
    
    print("=" * 70)
    print("  KotH Master Exploit Orchestrator")
    print(f"  Targets: {len(TARGETS)} machines")
    print(f"  Time:    {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)
    
    # Filter targets if specific one requested
    if args.target:
        if args.target in TARGETS:
            targets = {args.target: TARGETS[args.target]}
        else:
            print(f"[-] Unknown target: {args.target}")
            print(f"[*] Available targets: {', '.join(TARGETS.keys())}")
            sys.exit(1)
    else:
        targets = TARGETS
    
    # Check dependencies
    print("\n[*] Checking dependencies...")
    try:
        import requests
        print("[+] requests module available")
    except ImportError:
        print("[-] requests module not found!")
        print("[*] Run ./setup.sh first to create venv and install dependencies")
        print("[*] Then: source venv/bin/activate && python3 run_all.py")
        sys.exit(1)
    
    # Run exploits
    results = {}
    start_time = time.time()
    
    for ip, info in targets.items():
        exploit_start = time.time()
        success, message = run_exploit(ip, info)
        elapsed = time.time() - exploit_start
        results[ip] = {
            "name": info["name"],
            "success": success,
            "message": message,
            "time": f"{elapsed:.1f}s",
        }
        
        status = "[+] SUCCESS" if success else "[-] FAILED"
        print(f"\n{status}: {ip} — {info['name']} ({elapsed:.1f}s)")
        print("-" * 40)
        
        # Small delay between targets
        if len(targets) > 1:
            time.sleep(2)
    
    # Print summary
    total_time = time.time() - start_time
    
    print("\n" + "=" * 70)
    print("  EXPLOITATION SUMMARY")
    print("=" * 70)
    print(f"{'IP':<20} {'Service':<30} {'Result':<10} {'Time':<10}")
    print("-" * 70)
    
    successes = 0
    for ip, r in results.items():
        status = "OK" if r["success"] else "FAIL"
        print(f"{ip:<20} {r['name']:<30} {status:<10} {r['time']:<10}")
        if r["success"]:
            successes += 1
    
    print("-" * 70)
    print(f"Total: {successes}/{len(results)} successful | Time: {total_time:.1f}s")
    print("=" * 70)
    
    # Note about .240/.241
    print("\n[*] Note: 172.29.3.240 and 172.29.3.241 only have DNS (port 53)")
    print("[*] No exploitable services identified on those hosts.")
    
    if successes < len(results):
        print("\n[!] Some exploits failed. Check output above for details.")
        print("[*] Failed targets may need manual intervention.")


if __name__ == "__main__":
    main()
